# ****************************************************
# Normalize
# ****************************************************
def normalize(sound):
  largest = 0
  for s in getSamples(sound):
    largest = max(largest, getSampleValue(s))
  multiplier = 32767.0 / largest
  for s in getSamples(sound):
    louder = multiplier * getSampleValue(s)
    setSampleValue(s, louder)
  return sound

# ****************************************************
# Program 148: Write a Sound to a File as Text Numbers
# ****************************************************
def soundToText(sound, filename):
  file = open(filename, "wt")
  for s in getSamples(sound):
    file.write(str(getSample(s)) + "\n")
  file.close()
  
# TEST
#setMediaPath()
#file = "number9.wav"
#soundObj = makeSound(file)
#soundToText(soundObj, getMediaPath("output.txt"))

# ****************************************************
# Program 149: Convert a File of Text Numbers into a Sound
# ****************************************************
def textToSound(filename):
  #sound = makeSound(getMediaPath("sec3silence.wav"))
  sound = makeEmptySoundBySeconds(5, 44000)
  soundIndex = 0
  file = open(filename,"rt") 
  contents=file.readlines() 
  file.close() 
  fileIndex = 0
  while (soundIndex < getLength(sound)) and (fileIndex < len(contents)): #typo in book
     sample=float(contents[fileIndex])
     setSampleValueAt(sound,soundIndex,sample)
     fileIndex = fileIndex + 1 
     soundIndex = soundIndex + 1 
  return sound

# TEST
#inputFile = (getMediaPath("output.txt"))
#sound = textToSound(inputFile)
#sound = normalize(sound)
#explore(sound)
#writeSoundTo(sound,getMediaPath("output.wav"))

# ****************************************************
# Program 150: Visualizing a Sound
# ****************************************************
def soundToPicture(sound):
    #picture = makePicture(getMediaPath("640x480.jpg"))
    picture = makeEmptyPicture(640,480)
    soundIndex = 0
    for p in getPixels(picture):
        if soundIndex >= getLength(sound):    # Not > as in textbook!
            break
        sample = getSampleValueAt(sound, soundIndex)
        if sample > 1000:
            setColor(p, red)
        if sample <-1000:
            setColor(p, blue)
        if sample <= 1000 and sample >= -1000:
            setColor(p, green)
        soundIndex = soundIndex + 1
    return picture

# TEST
#sound = makeSound("output.wav")
#picture = soundToPicture(sound)
#explore(picture)
#writePictureTo(picture,"output.bmp") #Use .bmp instead of .jpg

# ****************************************************
# Program 151: Hearing a picture
# ****************************************************
def pictureToSound(picture):
    sound = makeEmptySoundBySeconds(10)
    sndIndex = 0
    for p in getPixels(picture):
        if sndIndex == getLength(sound):
            break
        if (getRed(p) > 200):
            setSampleValueAt(sound, sndIndex, 1000)
        elif getBlue(p) > 200:
            setSampleValueAt(sound, sndIndex, -1000)
        elif getGreen(p) > 200:
            setSampleValueAt(sound, sndIndex, 0)
        sndIndex = sndIndex + 1
    return sound

# TEST
#picture = makePicture("output.bmp")
#sound = pictureToSound(picture)
#sound = normalize(sound)
#explore(sound)
#writeSoundTo(sound,"output2.wav")